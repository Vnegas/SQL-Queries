Oracle NoSQL Database 20.3.18 Community Edition: 2021-05-05 05:19:35 UTC

This is Oracle NoSQL Database, version 20.3.18 Community Edition.

To view the release and installation documentation, load the
distribution file doc/index.html into your web browser.
